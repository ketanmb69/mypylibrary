# jsonbyket
Advanced and easy to use JSON configuration for python. Lets the developer configure their JSON using JSON. That sounds weird, but it's pretty neat and useful for programs that let users customize the settings via JSON. 
 
**Can be installed via `pip3 install jsonbyket`**