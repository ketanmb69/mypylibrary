from jsonbyket.jsonbyket import jsonbyket as jbk
__version__ = "1.0.0"
jsonbyket = jbk
